# HRA001684 Hashimoto's Thyroiditis Bulk RNA-seq Pipeline

A production-ready **Nextflow DSL2** pipeline for processing paired-end bulk RNA-seq data from the NGDC GSA-Human dataset **HRA001684** — a Hashimoto's thyroiditis (HT) transcriptomics study comprising 74 thyroid tissue samples.

---

## Table of Contents

1. [Overview](#overview)
2. [Dataset](#dataset)
3. [Pipeline Steps](#pipeline-steps)
4. [Prerequisites](#prerequisites)
5. [Installation](#installation)
6. [Quick Start](#quick-start)
7. [Configuration](#configuration)
8. [HPC Submission](#hpc-submission)
9. [Expected Outputs](#expected-outputs)
10. [Troubleshooting](#troubleshooting)
11. [Citation](#citation)

---

## Overview

```
Raw FASTQs → FastQC → MultiQC → Trimmomatic → STAR → featureCounts → DESeq2
```

| Step | Tool | Version | Purpose |
|------|------|---------|---------|
| 1 | FastQC | 0.12.1 | Raw read quality control |
| 2 | MultiQC | 1.21 | Aggregate QC report |
| 3 | Trimmomatic | 0.39 | Adapter trimming (TruSeq3-PE) |
| 4 | STAR | 2.7.11b | Alignment to GRCh38 |
| 5 | featureCounts | 2.0.6 | Gene-level quantification (Gencode v38) |
| 6 | DESeq2 | 1.42.0 | Differential expression (HT vs Non-HT) |

---

## Dataset

| Field | Value |
|-------|-------|
| Accession | [HRA001684](https://ngdc.cncb.ac.cn/gsa-human/browse/HRA001684) |
| Database | NGDC GSA-Human |
| Tissue | Thyroid |
| Library | Paired-end RNA-seq (Illumina) |
| Total samples | 74 |
| HT samples | 16 (HRR568828–HRR568843) |
| Non-HT samples | 58 (HRR568844–HRR568901) |
| Reference genome | GRCh38 |
| Annotation | Gencode v38 |

> **Note:** The original publication reports 50 Non-HT samples; the HRA001684 accession contains 74 total runs (16 HT + 58 Non-HT). All 74 are included in this pipeline.

---

## Pipeline Steps

### 1. FastQC
Quality assessment of raw paired-end reads. Checks per-base quality, adapter content, GC distribution, and duplication levels.

### 2. MultiQC
Aggregates FastQC reports from all 74 samples into a single interactive HTML report. Run twice: once on raw reads, once on trimmed reads.

### 3. Trimmomatic
Removes Illumina TruSeq3-PE adapters and low-quality bases:
- `ILLUMINACLIP:TruSeq3-PE.fa:2:30:10:2:keepBothReads`
- `LEADING:3 TRAILING:3 SLIDINGWINDOW:4:15 MINLEN:36`

### 4. STAR Alignment
Aligns trimmed reads to GRCh38 with Gencode v38 annotation:
- Output: coordinate-sorted BAM (`--outSAMtype BAM SortedByCoordinate`)
- Also generates per-gene read counts (`--quantMode GeneCounts`)

### 5. featureCounts
Quantifies gene-level read counts from sorted BAMs:
- `-p` paired-end mode
- `-s 0` unstranded library
- `-t exon -g gene_id` exon-level, summarized by gene_id

### 6. DESeq2
Differential expression analysis:
- **Design**: `~ batch + condition` (batch-corrected)
- **Contrast**: `c("condition", "HT", "NonHT")`
- **LFC shrinkage**: apeglm (fallback: ashr)
- **Significance**: padj < 0.05, |log2FC| ≥ 1

---

## Prerequisites

### Software

| Tool | Version | Installation |
|------|---------|-------------|
| Nextflow | ≥ 23.04.0 | `curl -s https://get.nextflow.io | bash` |
| Docker | ≥ 20.10 | [docs.docker.com](https://docs.docker.com/get-docker/) |
| Singularity | ≥ 3.8 | [sylabs.io](https://sylabs.io/guides/3.8/user-guide/quick_start.html) |
| Java | ≥ 11 | Required by Nextflow |

> Docker is required for the `local` profile. Singularity is used on HPC (`slurm`/`lsf` profiles).

### Reference Files

Download GRCh38 genome and Gencode v38 annotation:

```bash
# Download reference files
mkdir -p reference

# Gencode v38 GTF
wget -c -P reference/ \
    https://ftp.ebi.ac.uk/pub/databases/gencode/Gencode_human/release_38/gencode.v38.annotation.gtf.gz
gunzip reference/gencode.v38.annotation.gtf.gz

# GRCh38 primary assembly FASTA
wget -c -P reference/ \
    https://ftp.ebi.ac.uk/pub/databases/gencode/Gencode_human/release_38/GRCh38.primary_assembly.genome.fa.gz
gunzip reference/GRCh38.primary_assembly.genome.fa.gz

# Build STAR genome index (~30 GB RAM, ~1 hour)
mkdir -p reference/star_index_GRCh38_gencode38
STAR \
    --runMode genomeGenerate \
    --runThreadN 16 \
    --genomeDir reference/star_index_GRCh38_gencode38 \
    --genomeFastaFiles reference/GRCh38.primary_assembly.genome.fa \
    --sjdbGTFfile reference/gencode.v38.annotation.gtf \
    --sjdbOverhang 149
```

Or use the helper script:
```bash
bash bin/download_hra001684.sh --ref
```

---

## Installation

```bash
# 1. Clone or download this pipeline
git clone <repository_url> hra001684_pipeline
cd hra001684_pipeline

# 2. Install Nextflow (if not already installed)
curl -s https://get.nextflow.io | bash
sudo mv nextflow /usr/local/bin/

# 3. Verify Nextflow installation
nextflow -version

# 4. Pull Docker containers (optional, done automatically on first run)
docker pull quay.io/biocontainers/fastqc:0.12.1--hdfd78af_0
docker pull quay.io/biocontainers/multiqc:1.21--pyhdfd78af_0
docker pull quay.io/biocontainers/trimmomatic:0.39--hdfd78af_2
docker pull quay.io/biocontainers/star:2.7.11b--h43eeafb_0
docker pull quay.io/biocontainers/subread:2.0.6--he4a0461_0
docker pull quay.io/biocontainers/bioconductor-deseq2:1.42.0--r43hf17093f_2
```

---

## Quick Start

### Step 1: Download FASTQ files

```bash
# Download all 74 samples using wget (default)
bash bin/download_hra001684.sh --outdir data/fastq --threads 4

# Or use Aspera for faster download (requires IBM Aspera CLI)
bash bin/download_hra001684.sh --outdir data/fastq --method aspera --threads 8

# Dry-run to preview commands
bash bin/download_hra001684.sh --dry-run
```

### Step 2: Download reference genome

```bash
bash bin/download_hra001684.sh --ref
```

### Step 3: Update params.yaml

Edit `params.yaml` to set correct paths:

```yaml
genome_dir: "reference/star_index_GRCh38_gencode38"
gtf:        "reference/gencode.v38.annotation.gtf"
reads:      "data/fastq/HRR{568828..568901}_{1,2}.fastq.gz"
outdir:     "results"
```

### Step 4: Run the pipeline

```bash
# Local execution with Docker
nextflow run main.nf \
    -params-file params.yaml \
    -profile local \
    -resume

# With explicit output directory
nextflow run main.nf \
    -params-file params.yaml \
    -profile local \
    --outdir results/hra001684 \
    -resume
```

### Step 5: Check results

```bash
ls results/
# fastqc/       - Per-sample FastQC reports
# multiqc/      - Aggregated QC reports
# trimmomatic/  - Trimming logs
# star/         - Aligned BAMs and gene count tables
# featurecounts/- Per-sample count matrices
# deseq2/       - DESeq2 results, plots, normalized counts
# pipeline_info/- Execution timeline, report, trace
```

---

## Configuration

### params.yaml

Key parameters to configure:

```yaml
reads:      "data/fastq/HRR{568828..568901}_{1,2}.fastq.gz"
genome_dir: "reference/star_index_GRCh38_gencode38"
gtf:        "reference/gencode.v38.annotation.gtf"
outdir:     "results"
adapters:   "TruSeq3-PE.fa"
deseq2_fdr: 0.05
deseq2_lfc: 1.0
max_cpus:   16
max_memory: "128.GB"
```

### Resource Limits

Override resource limits via CLI or params.yaml:

```bash
nextflow run main.nf \
    -params-file params.yaml \
    -profile local \
    --max_cpus 8 \
    --max_memory 64.GB \
    --max_time 48.h
```

### Profiles

| Profile | Executor | Container | Use Case |
|---------|----------|-----------|----------|
| `local` | local | Docker | Workstation/laptop |
| `slurm` | SLURM | Singularity | HPC with SLURM |
| `lsf` | LSF | Singularity | HPC with LSF/Platform |
| `docker` | local | Docker | CI/testing |
| `singularity` | local | Singularity | Local + Singularity |
| `test` | local | Docker | Quick test (small data) |

---

## HPC Submission

### SLURM

```bash
# Basic SLURM submission
nextflow run main.nf \
    -params-file params.yaml \
    -profile slurm \
    --max_cpus 32 \
    --max_memory 256.GB \
    -resume

# With SLURM account specification
nextflow run main.nf \
    -params-file params.yaml \
    -profile slurm \
    --slurm_account myproject \
    --max_cpus 32 \
    --max_memory 256.GB \
    -resume

# Submit Nextflow itself as a SLURM job (recommended for long runs)
sbatch << 'EOF'
#!/bin/bash
#SBATCH --job-name=hra001684_rnaseq
#SBATCH --output=logs/nextflow_%j.log
#SBATCH --error=logs/nextflow_%j.err
#SBATCH --time=72:00:00
#SBATCH --mem=8G
#SBATCH --cpus-per-task=2
#SBATCH --partition=short

module load nextflow singularity

nextflow run main.nf \
    -params-file params.yaml \
    -profile slurm \
    --slurm_account myproject \
    --max_cpus 32 \
    --max_memory 256.GB \
    -resume \
    -with-report results/pipeline_info/report.html \
    -with-trace results/pipeline_info/trace.txt \
    -with-timeline results/pipeline_info/timeline.html
EOF
```

### LSF (Platform LSF / IBM Spectrum LSF)

```bash
# Basic LSF submission
nextflow run main.nf \
    -params-file params.yaml \
    -profile lsf \
    --max_cpus 32 \
    --max_memory 256.GB \
    -resume

# Submit Nextflow itself as an LSF job
bsub << 'EOF'
#!/bin/bash
#BSUB -J hra001684_rnaseq
#BSUB -o logs/nextflow_%J.log
#BSUB -e logs/nextflow_%J.err
#BSUB -W 72:00
#BSUB -M 8192
#BSUB -n 2
#BSUB -q normal

module load nextflow singularity

nextflow run main.nf \
    -params-file params.yaml \
    -profile lsf \
    --lsf_project myproject \
    --max_cpus 32 \
    --max_memory 256.GB \
    -resume
EOF
```

### Singularity Cache

Pre-pull Singularity images to avoid repeated downloads:

```bash
export NXF_SINGULARITY_CACHEDIR=/path/to/singularity/cache
mkdir -p ${NXF_SINGULARITY_CACHEDIR}

# Pull all containers
singularity pull ${NXF_SINGULARITY_CACHEDIR}/fastqc.sif \
    docker://quay.io/biocontainers/fastqc:0.12.1--hdfd78af_0
singularity pull ${NXF_SINGULARITY_CACHEDIR}/multiqc.sif \
    docker://quay.io/biocontainers/multiqc:1.21--pyhdfd78af_0
singularity pull ${NXF_SINGULARITY_CACHEDIR}/trimmomatic.sif \
    docker://quay.io/biocontainers/trimmomatic:0.39--hdfd78af_2
singularity pull ${NXF_SINGULARITY_CACHEDIR}/star.sif \
    docker://quay.io/biocontainers/star:2.7.11b--h43eeafb_0
singularity pull ${NXF_SINGULARITY_CACHEDIR}/subread.sif \
    docker://quay.io/biocontainers/subread:2.0.6--he4a0461_0
singularity pull ${NXF_SINGULARITY_CACHEDIR}/deseq2.sif \
    docker://quay.io/biocontainers/bioconductor-deseq2:1.42.0--r43hf17093f_2
```

---

## Expected Outputs

```
results/
├── fastqc/
│   └── raw/
│       ├── HRR568828_1_fastqc.html
│       ├── HRR568828_1_fastqc.zip
│       └── ... (2 files × 74 samples = 148 files)
│
├── multiqc/
│   ├── raw_qc/
│   │   └── multiqc_report.html          # Raw reads QC summary
│   └── trim_qc/
│       └── multiqc_report.html          # Post-trimming QC summary
│
├── trimmomatic/
│   └── logs/
│       ├── HRR568828.trimmomatic.log
│       └── ... (74 log files)
│
├── star/
│   ├── bam/
│   │   ├── HRR568828.Aligned.sortedByCoord.out.bam
│   │   ├── HRR568828.Aligned.sortedByCoord.out.bam.bai
│   │   └── ... (2 files × 74 samples)
│   ├── counts/
│   │   ├── HRR568828.ReadsPerGene.out.tab
│   │   └── ... (74 files)
│   └── logs/
│       ├── HRR568828.Log.final.out
│       └── ... (74 files)
│
├── featurecounts/
│   ├── HRR568828.featureCounts.txt
│   ├── HRR568828.featureCounts.txt.summary
│   └── ... (2 files × 74 samples)
│
├── deseq2/
│   ├── samplesheet.csv                  # Auto-generated sample metadata
│   ├── deseq2_results_all.csv           # All genes (shrunk LFC)
│   ├── deseq2_DEGs_padj0.05_lfc1.csv   # Significant DEGs
│   ├── normalized_counts_vst.csv        # VST-normalized count matrix
│   ├── pca_plot.png                     # PCA of VST counts
│   ├── volcano_plot.png                 # Volcano plot
│   ├── heatmap_top50_DEGs.png           # Heatmap of top 50 DEGs
│   ├── dispersion_plot.png              # DESeq2 dispersion estimates
│   ├── MA_plot.png                      # MA plot (shrunk LFC)
│   ├── deseq2_summary.txt               # Text summary report
│   └── deseq2_analysis.RData            # Full R environment
│
└── pipeline_info/
    ├── execution_timeline_*.html        # Process timeline
    ├── execution_report_*.html          # Resource usage report
    ├── execution_trace_*.txt            # Detailed trace
    └── pipeline_dag_*.svg               # Pipeline DAG
```

### DESeq2 Output Columns

`deseq2_results_all.csv`:

| Column | Description |
|--------|-------------|
| `gene_id` | Ensembl gene ID (Gencode v38) |
| `baseMean` | Mean normalized count across all samples |
| `log2FoldChange` | Shrunk log2 fold change (HT / NonHT) |
| `lfcSE` | Standard error of LFC |
| `stat` | Wald statistic |
| `pvalue` | Raw p-value |
| `padj` | BH-adjusted p-value |

---

## Troubleshooting

### Common Issues

**1. STAR runs out of memory**
```bash
# Increase memory limit
nextflow run main.nf -params-file params.yaml -profile local \
    --max_memory 128.GB
```

**2. Trimmomatic adapter file not found**
```bash
# The adapter file is bundled in the Trimmomatic container.
# If using a custom adapter file, mount it:
docker run -v /path/to/adapters:/adapters trimmomatic ...
```

**3. featureCounts reports low assignment rate**
- Check library strandedness: try `-s 1` (forward) or `-s 2` (reverse)
- Verify GTF matches the genome assembly version

**4. DESeq2 fails with "model matrix not full rank"**
- Check for confounded batch/condition design
- Reduce batch granularity in `params.yaml`

**5. Resume a failed run**
```bash
nextflow run main.nf -params-file params.yaml -profile local -resume
```

**6. Clean work directory**
```bash
nextflow clean -f
# Or remove specific runs:
nextflow log | head -5
nextflow clean <run_name> -f
```

### Checking Logs

```bash
# View Nextflow log
cat .nextflow.log

# View process-specific logs
ls work/
# Navigate to the work directory of a failed process
cat work/ab/cdef1234.../command.log
cat work/ab/cdef1234.../command.err
```

---

## Citation

If you use this pipeline, please cite:

### Dataset
```
HRA001684. Hashimoto's thyroiditis thyroid tissue RNA-seq.
NGDC GSA-Human. https://ngdc.cncb.ac.cn/gsa-human/browse/HRA001684
```

### Tools

```
FastQC: Andrews S. (2010). FastQC: A Quality Control Tool for High Throughput Sequence Data.
        http://www.bioinformatics.babraham.ac.uk/projects/fastqc/

MultiQC: Ewels P, et al. (2016). MultiQC: summarize analysis results for multiple tools
         and samples in a single report. Bioinformatics, 32(19):3047-3048.
         doi:10.1093/bioinformatics/btw354

Trimmomatic: Bolger AM, et al. (2014). Trimmomatic: a flexible trimmer for Illumina
             sequence data. Bioinformatics, 30(15):2114-2120.
             doi:10.1093/bioinformatics/btu170

STAR: Dobin A, et al. (2013). STAR: ultrafast universal RNA-seq aligner.
      Bioinformatics, 29(1):15-21. doi:10.1093/bioinformatics/bts635

featureCounts: Liao Y, et al. (2014). featureCounts: an efficient general purpose
               program for assigning sequence reads to genomic features.
               Bioinformatics, 30(7):923-930. doi:10.1093/bioinformatics/btt656

DESeq2: Love MI, et al. (2014). Moderated estimation of fold change and dispersion
        for RNA-seq data with DESeq2. Genome Biology, 15:550.
        doi:10.1186/s13059-014-0550-8

Nextflow: Di Tommaso P, et al. (2017). Nextflow enables reproducible computational
          workflows. Nature Biotechnology, 35:316-319. doi:10.1038/nbt.3820

Gencode v38: Frankish A, et al. (2021). GENCODE 2021. Nucleic Acids Research,
             49(D1):D916-D923. doi:10.1093/nar/gkaa1087
```

---

## License

MIT License. See [LICENSE](LICENSE) for details.

---

## Contact

For pipeline issues, please open a GitHub issue or contact the pipeline maintainer.
For dataset access issues, contact NGDC: [ngdc@cncb.ac.cn](mailto:ngdc@cncb.ac.cn)
