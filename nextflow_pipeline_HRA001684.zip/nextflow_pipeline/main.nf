#!/usr/bin/env nextflow

/*
========================================================================================
    HRA001684 Hashimoto's Thyroiditis Bulk RNA-seq Pipeline
========================================================================================
    Nextflow DSL2 pipeline for processing paired-end RNA-seq data from NGDC HRA001684
    (74 samples: 16 HT + 58 Non-HT thyroid tissue samples)

    Steps:
        1. FastQC        - Raw read quality control
        2. MultiQC       - Aggregate QC report (raw + post-trim)
        3. Trimmomatic   - Adapter trimming (TruSeq3-PE)
        4. STAR          - Alignment to GRCh38
        5. featureCounts - Gene-level quantification (Gencode v38)
        6. DESeq2        - Differential expression analysis (HT vs Non-HT)

    Author  : HRA001684 Pipeline
    License : MIT
========================================================================================
*/

nextflow.enable.dsl = 2

// ─── Parameter validation ────────────────────────────────────────────────────

def requiredParams = ['reads', 'genome_dir', 'gtf', 'outdir']
requiredParams.each { p ->
    if (!params[p]) {
        error "Required parameter '--${p}' is missing. Please supply it via params.yaml or CLI."
    }
}

// ─── Print pipeline header ───────────────────────────────────────────────────

log.info """
╔══════════════════════════════════════════════════════════════════════════════╗
║          HRA001684 Hashimoto's Thyroiditis RNA-seq Pipeline                 ║
╚══════════════════════════════════════════════════════════════════════════════╝
  reads          : ${params.reads}
  genome_dir     : ${params.genome_dir}
  gtf            : ${params.gtf}
  outdir         : ${params.outdir}
  adapters       : ${params.adapters}
  HT samples     : ${params.ht_samples.size()} samples
  Non-HT samples : ${params.nonht_samples.size()} samples
  max_cpus       : ${params.max_cpus}
  max_memory     : ${params.max_memory}
""".stripIndent()

// ─── Module imports ──────────────────────────────────────────────────────────

include { FASTQC          } from './modules/fastqc'
include { MULTIQC         } from './modules/multiqc'
include { TRIMMOMATIC     } from './modules/trimmomatic'
include { STAR_ALIGN      } from './modules/star_align'
include { FEATURECOUNTS   } from './modules/featurecounts'
include { DESEQ2          } from './modules/deseq2'

// ─── Helper: build sample metadata map ───────────────────────────────────────

def buildConditionMap(htSamples, nonhtSamples) {
    def allSamples = [:]
    htSamples.each    { id -> allSamples[id] = 'HT'    }
    nonhtSamples.each { id -> allSamples[id] = 'NonHT' }
    return allSamples
}

// ─── Main workflow ───────────────────────────────────────────────────────────

workflow {

    // Build condition map
    def conditionMap = buildConditionMap(
        params.ht_samples,
        params.nonht_samples
    )

    // Sorted list of all sample IDs for batch assignment
    def allIds = (params.ht_samples + params.nonht_samples).sort()

    // ── Input channel: paired FASTQ files ────────────────────────────────────
    // Each element: [ meta, [ read1, read2 ] ]
    // meta = [ id: 'HRRxxxxxx', condition: 'HT'|'NonHT', batch: <int> ]
    ch_reads = Channel
        .fromFilePairs(params.reads, checkIfExists: true)
        .map { sample_id, files ->
            def condition = conditionMap.containsKey(sample_id)
                ? conditionMap[sample_id]
                : 'Unknown'
            // Assign batch based on run order (groups of 12 for batch correction)
            def idx   = allIds.indexOf(sample_id)
            def batch = (idx >= 0) ? (idx.intdiv(12) + 1) : 1
            def meta  = [ id: sample_id, condition: condition, batch: batch ]
            return [ meta, files ]
        }

    // ── Step 1: FastQC on raw reads ───────────────────────────────────────────
    FASTQC(ch_reads)

    // ── Step 2a: MultiQC on raw FastQC results ────────────────────────────────
    ch_raw_fastqc_zips = FASTQC.out.zip
        .map { meta, zip_files -> zip_files }
        .flatten()
        .collect()

    MULTIQC(ch_raw_fastqc_zips, "raw_qc")

    // ── Step 3: Trimmomatic adapter trimming ─────────────────────────────────
    TRIMMOMATIC(ch_reads)

    // ── Step 4: STAR alignment ────────────────────────────────────────────────
    STAR_ALIGN(
        TRIMMOMATIC.out.trimmed_reads,
        params.genome_dir,
        params.gtf
    )

    // ── Step 5: featureCounts quantification ─────────────────────────────────
    FEATURECOUNTS(
        STAR_ALIGN.out.bam,
        params.gtf
    )

    // ── Step 6: DESeq2 differential expression ───────────────────────────────
    // Collect all per-sample count files
    ch_counts_collected = FEATURECOUNTS.out.counts
        .map { meta, counts -> counts }
        .collect()

    // Build samplesheet CSV from metadata carried through the pipeline
    ch_samplesheet = FEATURECOUNTS.out.counts
        .map { meta, counts -> "${meta.id},${meta.condition},${meta.batch}" }
        .collectFile(
            name:     'samplesheet.csv',
            newLine:  true,
            seed:     'sample_id,condition,batch',
            storeDir: "${params.outdir}/deseq2"
        )

    DESEQ2(
        ch_counts_collected,
        ch_samplesheet
    )
}

// ─── Workflow completion handler ─────────────────────────────────────────────

workflow.onComplete {
    def status = workflow.success ? "SUCCESS" : "FAILED"
    log.info """
    ════════════════════════════════════════════════════════
    Pipeline ${status}
    Completed at : ${workflow.complete}
    Duration     : ${workflow.duration}
    Work dir     : ${workflow.workDir}
    Output dir   : ${params.outdir}
    Exit status  : ${workflow.exitStatus}
    ════════════════════════════════════════════════════════
    """.stripIndent()
}

workflow.onError {
    log.error "Pipeline failed with error: ${workflow.errorMessage}"
}
