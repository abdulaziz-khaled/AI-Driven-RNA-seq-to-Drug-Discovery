/*
========================================================================================
    MODULE: DESeq2 Differential Expression
========================================================================================
    Runs DESeq2 differential expression analysis comparing HT vs Non-HT samples.
    Uses batch-corrected design: ~ batch + condition
    Calls the bin/deseq2_analysis.R script.

    Input  :
        counts      - collected list of featureCounts output files
        samplesheet - CSV with columns: sample_id, condition, batch
    Output :
        results     - DESeq2 results table (all genes)
        degs        - Significant DEGs (padj < 0.05, |log2FC| >= 1)
        norm_counts - Normalized count matrix (VST)
        pca_plot    - PCA plot PNG
        volcano     - Volcano plot PNG
        rdata       - RData object for downstream analysis
========================================================================================
*/

process DESEQ2 {

    tag "HT_vs_NonHT"
    label 'process_medium'

    container 'quay.io/biocontainers/bioconductor-deseq2:1.42.0--r43hf17093f_2'

    publishDir(
        path:    "${params.outdir}/deseq2",
        mode:    'copy',
        pattern: '*.{csv,tsv,png,RData,txt}'
    )

    input:
    path(count_files)
    path(samplesheet)

    output:
    path("deseq2_results_all.csv"),          emit: results
    path("deseq2_DEGs_padj0.05_lfc1.csv"),  emit: degs
    path("normalized_counts_vst.csv"),       emit: norm_counts
    path("pca_plot.png"),                    emit: pca_plot
    path("volcano_plot.png"),                emit: volcano
    path("deseq2_analysis.RData"),           emit: rdata
    path("deseq2_summary.txt"),              emit: summary

    when:
    task.ext.when == null || task.ext.when

    script:
    def fdr = params.deseq2_fdr ?: 0.05
    def lfc = params.deseq2_lfc ?: 1.0
    """
    Rscript ${projectDir}/bin/deseq2_analysis.R \\
        --count_dir . \\
        --samplesheet ${samplesheet} \\
        --outdir . \\
        --fdr ${fdr} \\
        --lfc ${lfc} \\
        --condition_col condition \\
        --batch_col batch \\
        --contrast_ref NonHT \\
        --contrast_trt HT

    echo "DESeq2 analysis completed."
    """

    stub:
    """
    touch deseq2_results_all.csv
    touch deseq2_DEGs_padj0.05_lfc1.csv
    touch normalized_counts_vst.csv
    touch pca_plot.png
    touch volcano_plot.png
    touch deseq2_analysis.RData
    echo "STUB: DESeq2 summary" > deseq2_summary.txt
    """
}
