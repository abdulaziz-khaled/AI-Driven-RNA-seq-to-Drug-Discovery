/*
========================================================================================
    MODULE: FastQC
========================================================================================
    Runs FastQC quality control on raw paired-end FASTQ files.

    Input  : [ meta, [ read1, read2 ] ]
    Output :
        zip  - [ meta, [ *_fastqc.zip  ] ]
        html - [ meta, [ *_fastqc.html ] ]
========================================================================================
*/

process FASTQC {

    tag "${meta.id}"
    label 'process_medium'

    container 'quay.io/biocontainers/fastqc:0.12.1--hdfd78af_0'

    publishDir(
        path:    "${params.outdir}/fastqc/raw",
        mode:    'copy',
        pattern: '*.{html,zip}'
    )

    input:
    tuple val(meta), path(reads)

    output:
    tuple val(meta), path('*.zip'),  emit: zip
    tuple val(meta), path('*.html'), emit: html

    when:
    task.ext.when == null || task.ext.when

    script:
    def prefix = meta.id
    def read_list = reads.collect { it.toString() }.join(' ')
    """
    fastqc \\
        --threads ${task.cpus} \\
        --outdir . \\
        --format fastq \\
        ${read_list}

    # Rename outputs to include sample prefix if needed
    for f in *.zip *.html; do
        if [[ "\$f" != ${prefix}_* ]]; then
            base=\$(basename "\$f")
            mv "\$f" "${prefix}_\${base}" 2>/dev/null || true
        fi
    done
    """

    stub:
    def prefix = meta.id
    """
    touch ${prefix}_R1_fastqc.zip
    touch ${prefix}_R2_fastqc.zip
    touch ${prefix}_R1_fastqc.html
    touch ${prefix}_R2_fastqc.html
    """
}
