/*
========================================================================================
    MODULE: featureCounts
========================================================================================
    Quantifies gene-level read counts from sorted BAM files using featureCounts
    (Subread package). Configured for paired-end, unstranded RNA-seq.

    Input  :
        bam - [ meta, sorted_bam, bam_index ]
        gtf - path to Gencode v38 GTF annotation
    Output :
        counts   - [ meta, counts_txt ]
        summary  - [ meta, counts_summary ]
========================================================================================
*/

process FEATURECOUNTS {

    tag "${meta.id}"
    label 'process_medium'

    container 'quay.io/biocontainers/subread:2.0.6--he4a0461_0'

    publishDir(
        path:    "${params.outdir}/featurecounts",
        mode:    'copy',
        pattern: '*.{txt,summary}'
    )

    input:
    tuple val(meta), path(bam), path(bai)
    path(gtf)

    output:
    tuple val(meta), path("${meta.id}.featureCounts.txt"),         emit: counts
    tuple val(meta), path("${meta.id}.featureCounts.txt.summary"), emit: summary

    when:
    task.ext.when == null || task.ext.when

    script:
    def prefix    = meta.id
    def extra_args = params.featurecounts_extra_args ?: '-s 0 -t exon -g gene_id'
    """
    featureCounts \\
        -T ${task.cpus} \\
        -p \\
        --countReadPairs \\
        -a ${gtf} \\
        -o ${prefix}.featureCounts.txt \\
        ${extra_args} \\
        ${bam}

    echo "featureCounts completed for ${prefix}"
    echo "Assignment summary:"
    cat ${prefix}.featureCounts.txt.summary
    """

    stub:
    def prefix = meta.id
    """
    # Create minimal featureCounts output format
    printf "# Program:featureCounts v2.0.6\\n" > ${prefix}.featureCounts.txt
    printf "Geneid\\tChr\\tStart\\tEnd\\tStrand\\tLength\\t${bam}\\n" >> ${prefix}.featureCounts.txt
    printf "ENSG00000000003.15\\tchrX\\t100627108\\t100639991\\t-\\t4535\\t100\\n" >> ${prefix}.featureCounts.txt

    printf "Status\\t${bam}\\n" > ${prefix}.featureCounts.txt.summary
    printf "Assigned\\t1000000\\n" >> ${prefix}.featureCounts.txt.summary
    printf "Unassigned_Unmapped\\t50000\\n" >> ${prefix}.featureCounts.txt.summary
    """
}
