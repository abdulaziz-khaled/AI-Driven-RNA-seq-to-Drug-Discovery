/*
========================================================================================
    MODULE: MultiQC
========================================================================================
    Aggregates QC reports from FastQC and Trimmomatic into a single HTML report.

    Input  : path(qc_files) - collected list of QC output files
             val(report_name) - label for the report (e.g. "raw_qc", "trim_qc")
    Output :
        report - path to MultiQC HTML report
        data   - path to MultiQC data directory (zip)
========================================================================================
*/

process MULTIQC {

    tag "${report_name}"
    label 'process_single'

    container 'quay.io/biocontainers/multiqc:1.21--pyhdfd78af_0'

    publishDir(
        path:    "${params.outdir}/multiqc/${report_name}",
        mode:    'copy',
        pattern: 'multiqc_*'
    )

    input:
    path(qc_files)
    val(report_name)

    output:
    path("multiqc_report.html"),    emit: report
    path("multiqc_data"),           emit: data,   optional: true
    path("multiqc_plots"),          emit: plots,  optional: true

    when:
    task.ext.when == null || task.ext.when

    script:
    """
    multiqc \\
        --title "HRA001684 ${report_name}" \\
        --comment "Hashimoto Thyroiditis RNA-seq QC - ${report_name}" \\
        --filename multiqc_report.html \\
        --outdir . \\
        .

    # Rename report to include label
    mv multiqc_report.html multiqc_report.html
    """

    stub:
    """
    mkdir -p multiqc_data multiqc_plots
    touch multiqc_report.html
    touch multiqc_data/multiqc_general_stats.txt
    """
}
