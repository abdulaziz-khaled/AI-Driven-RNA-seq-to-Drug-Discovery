/*
========================================================================================
    MODULE: STAR Alignment
========================================================================================
    Aligns trimmed paired-end reads to GRCh38 using STAR.
    Outputs coordinate-sorted BAM files and per-gene read counts.

    Input  :
        reads      - [ meta, [ trimmed_R1, trimmed_R2 ] ]
        genome_dir - path to STAR genome index directory
        gtf        - path to Gencode v38 GTF annotation
    Output :
        bam        - [ meta, sorted_bam, bam_index ]
        log        - [ meta, STAR_Log.final.out ]
        counts     - [ meta, ReadsPerGene.out.tab ]
        sj         - [ meta, SJ.out.tab ]
========================================================================================
*/

process STAR_ALIGN {

    tag "${meta.id}"
    label 'process_high'

    container 'quay.io/biocontainers/star:2.7.11b--h43eeafb_0'

    publishDir(
        path:    "${params.outdir}/star",
        mode:    'copy',
        pattern: '*.{bam,bai,tab,out}',
        saveAs:  { filename ->
            if (filename.endsWith('.bam'))           "bam/${filename}"
            else if (filename.endsWith('.bai'))      "bam/${filename}"
            else if (filename.endsWith('.final.out')) "logs/${filename}"
            else if (filename.endsWith('.tab'))      "counts/${filename}"
            else                                     "logs/${filename}"
        }
    )

    input:
    tuple val(meta), path(reads)
    path(genome_dir)
    path(gtf)

    output:
    tuple val(meta), path("${meta.id}.Aligned.sortedByCoord.out.bam"),
                     path("${meta.id}.Aligned.sortedByCoord.out.bam.bai"), emit: bam
    tuple val(meta), path("${meta.id}.Log.final.out"),                     emit: log
    tuple val(meta), path("${meta.id}.ReadsPerGene.out.tab"),              emit: counts
    tuple val(meta), path("${meta.id}.SJ.out.tab"),                        emit: sj

    when:
    task.ext.when == null || task.ext.when

    script:
    def prefix      = meta.id
    def read1       = reads[0]
    def read2       = reads[1]
    def extra_args  = params.star_extra_args ?: ''
    """
    STAR \\
        --runThreadN ${task.cpus} \\
        --genomeDir ${genome_dir} \\
        --sjdbGTFfile ${gtf} \\
        --readFilesIn ${read1} ${read2} \\
        --readFilesCommand zcat \\
        --outSAMtype BAM SortedByCoordinate \\
        --outSAMunmapped Within \\
        --quantMode GeneCounts \\
        --outFileNamePrefix ${prefix}. \\
        --outSAMstrandField intronMotif \\
        --outFilterIntronMotifs RemoveNoncanonical \\
        --outSAMattrRGline ID:${prefix} SM:${prefix} PL:ILLUMINA LB:${prefix} \\
        --limitBAMsortRAM \$(echo "${task.memory}" | sed 's/ GB//' | awk '{printf "%d", \$1 * 0.8 * 1073741824}') \\
        ${extra_args}

    # Index the sorted BAM
    samtools index -@ ${task.cpus} ${prefix}.Aligned.sortedByCoord.out.bam

    echo "STAR alignment completed for ${prefix}"
    echo "Mapping stats:"
    grep "Uniquely mapped reads %" ${prefix}.Log.final.out || true
    """

    stub:
    def prefix = meta.id
    """
    touch ${prefix}.Aligned.sortedByCoord.out.bam
    touch ${prefix}.Aligned.sortedByCoord.out.bam.bai
    touch ${prefix}.Log.final.out
    touch ${prefix}.ReadsPerGene.out.tab
    touch ${prefix}.SJ.out.tab
    """
}
