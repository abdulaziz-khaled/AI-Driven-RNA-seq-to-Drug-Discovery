/*
========================================================================================
    MODULE: Trimmomatic
========================================================================================
    Trims adapter sequences and low-quality bases from paired-end FASTQ files.
    Uses TruSeq3-PE adapters (Illumina standard paired-end).

    Input  : [ meta, [ read1, read2 ] ]
    Output :
        trimmed_reads - [ meta, [ trimmed_R1, trimmed_R2 ] ]
        log           - [ meta, trimmomatic_log ]
        unpaired      - [ meta, [ unpaired_R1, unpaired_R2 ] ]
========================================================================================
*/

process TRIMMOMATIC {

    tag "${meta.id}"
    label 'process_high'

    container 'quay.io/biocontainers/trimmomatic:0.39--hdfd78af_2'

    publishDir(
        path:    "${params.outdir}/trimmomatic",
        mode:    'copy',
        pattern: '*.log',
        saveAs:  { filename -> "logs/${filename}" }
    )

    input:
    tuple val(meta), path(reads)

    output:
    tuple val(meta), path("${meta.id}_{1,2}P.fastq.gz"),   emit: trimmed_reads
    tuple val(meta), path("${meta.id}.trimmomatic.log"),    emit: log
    tuple val(meta), path("${meta.id}_{1,2}U.fastq.gz"),   emit: unpaired, optional: true

    when:
    task.ext.when == null || task.ext.when

    script:
    def prefix   = meta.id
    def read1    = reads[0]
    def read2    = reads[1]
    def adapters = params.adapters
    def opts     = params.trimmomatic_opts ?: 'LEADING:3 TRAILING:3 SLIDINGWINDOW:4:15 MINLEN:36'

    // Trimmomatic ships adapter files inside the container at /usr/share/trimmomatic/
    // or /opt/conda/share/trimmomatic-*/adapters/
    """
    # Locate adapter file within container
    ADAPTER_PATH=""
    for dir in /usr/share/trimmomatic /opt/conda/share/trimmomatic*/adapters /usr/local/share/trimmomatic*/adapters; do
        if [ -f "\${dir}/${adapters}" ]; then
            ADAPTER_PATH="\${dir}/${adapters}"
            break
        fi
    done

    if [ -z "\${ADAPTER_PATH}" ]; then
        # Fall back: search broadly
        ADAPTER_PATH=\$(find / -name "${adapters}" 2>/dev/null | head -1)
    fi

    if [ -z "\${ADAPTER_PATH}" ]; then
        echo "ERROR: Adapter file '${adapters}' not found in container." >&2
        exit 1
    fi

    trimmomatic PE \\
        -threads ${task.cpus} \\
        -phred33 \\
        ${read1} ${read2} \\
        ${prefix}_1P.fastq.gz ${prefix}_1U.fastq.gz \\
        ${prefix}_2P.fastq.gz ${prefix}_2U.fastq.gz \\
        ILLUMINACLIP:\${ADAPTER_PATH}:2:30:10:2:keepBothReads \\
        ${opts} \\
        2> ${prefix}.trimmomatic.log

    echo "Trimmomatic completed for ${prefix}" >> ${prefix}.trimmomatic.log
    """

    stub:
    def prefix = meta.id
    """
    touch ${prefix}_1P.fastq.gz
    touch ${prefix}_2P.fastq.gz
    touch ${prefix}_1U.fastq.gz
    touch ${prefix}_2U.fastq.gz
    echo "STUB: Trimmomatic log for ${prefix}" > ${prefix}.trimmomatic.log
    """
}
